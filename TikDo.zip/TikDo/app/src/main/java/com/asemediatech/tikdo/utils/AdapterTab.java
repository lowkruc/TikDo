package com.asemediatech.tikdo.utils;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;

import com.asemediatech.tikdo.fregment.Download;
import com.asemediatech.tikdo.fregment.Galery;
import com.asemediatech.tikdo.fregment.Setting;



public class AdapterTab extends FragmentPagerAdapter {
    private int numOfTabs;
    public AdapterTab(FragmentManager fm, int numOfTabsx) {
        super(fm);
        this.numOfTabs = numOfTabsx;
    }

    @Override
    public Fragment getItem(int position) {
        Log.d("POSITION", String.valueOf(position));
        switch (position){
            case 0:
            return  new Download();
            case 1:
            return  new Galery();
            case 2:
            return  new Setting();
            default:
                return null;
        }
    }
    @Override
    public int getCount() {
        return numOfTabs;
    }
}
