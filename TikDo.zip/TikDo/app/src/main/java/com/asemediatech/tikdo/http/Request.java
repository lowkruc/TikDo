package com.asemediatech.tikdo.http;

import android.os.AsyncTask;
import android.util.Log;

import okhttp3.OkHttpClient;
import okhttp3.Response;

class Request{
    public static AsyncTask<Void, Void, String> getData(){
        String url = "https://api16-normal-c-alisg.tiktokv.com/aweme/v1/aweme/detail/?aweme_id=6871232569094966529&origin_type=web&request_source=0&storage_type=1&manifest_version_code=160702&_rticket=1599906993241&current_region=ID&app_language=en&app_type=normal&iid=6871537617181574917&channel=googleplay&device_type=AN0A7&language=en&cpu_support64=false&host_abi=armeabi-v7a&locale=en&resolution=1440*2816&openudid=fxki2tzi9cyhhcq&update_version_code=160702&ac2=wifi&cdid=bcdb0273-af16-4542-9359-292e789ca772&sys_region=US&appTheme=light&os_api=26&uoo=0&timezone_name=GMT&dpi=480&residence=UK&carrier_region=UK&ac=wifi&device_id=6871537129001960965&pass-route=1&os_version=8.0.0&timezone_offset=0&version_code=160702&carrier_region_v2=310&app_name=musically_go&ab_version=16.7.2&version_name=16.7.2&device_brand=Huawei&op_region=UK&ssmix=a&pass-region=1&device_platform=android&build_number=16.7.2&region=US&aid=1340&ts=1599906993";
        String gorgon = com.asemediatech.tikdo.utils.GenerateToken.getGorgon(url);

        final okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url)
                .header("sdk-version", "2")
                .header("passport-sdk-version", "17")
                .header("X-SS-REQ-TICKET", "1599906993243")
                .header("cookie", "install_id=6871537617181574917; ttreq=1$0ac72dde4392ece82bcb05c2b3946123768c0cab; odin_tt=e5c47d44fd9623581c07f43d472b1da75e0aedad6465a4573542e58878a2ac31f582dc3cb84962822ae3d45026050fffba1a6cbe680f0bb6cac789e498d6265b")
                .header("X-Khronos", "1599906993")
                .header("X-Gorgon", gorgon)
                .header("Host", "api16-normal-c-alisg.tiktokv.com")
                .build();

        final OkHttpClient client = new OkHttpClient();

        AsyncTask<Void, Void, String> asyncTask = new AsyncTask<Void, Void, String>() {
        @Override
        protected String doInBackground(Void... params) {
                try {
                    Response response = client.newCall(request).execute();
                    if (!response.isSuccessful()) {
                        return null;
                    }
                    return response.body().string();
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.w("Success", s);
        }
        };
        return asyncTask.execute();
    }
}