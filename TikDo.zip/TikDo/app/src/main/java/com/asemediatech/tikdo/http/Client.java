package com.asemediatech.tikdo.http;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Client {
    private static final String BASE_URL = "https://api16-normal-c-alisg.tiktokv.com/aweme/v1/aweme/detail/?aweme_id=6871232569094966529&origin_type=web&request_source=0&storage_type=1&manifest_version_code=160702&_rticket=1599906993241&current_region=ID&app_language=en&app_type=normal&iid=6871537617181574917&channel=googleplay&device_type=AN0A7&language=en&cpu_support64=false&host_abi=armeabi-v7a&locale=en&resolution=1440*2816&openudid=fxki2tzi9cyhhcq&update_version_code=160702&ac2=wifi&cdid=bcdb0273-af16-4542-9359-292e789ca772&sys_region=US&appTheme=light&os_api=26&uoo=0&timezone_name=GMT&dpi=480&residence=UK&carrier_region=UK&ac=wifi&device_id=6871537129001960965&pass-route=1&os_version=8.0.0&timezone_offset=0&version_code=160702&carrier_region_v2=310&app_name=musically_go&ab_version=16.7.2&version_name=16.7.2&device_brand=Huawei&op_region=UK&ssmix=a&pass-region=1&device_platform=android&build_number=16.7.2&region=US&aid=1340&ts=1599906993";

    private static Retrofit.Builder builder =
            new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create());

    private static Retrofit retrofit = builder.build();

    private static HttpLoggingInterceptor logging =
            new HttpLoggingInterceptor()
                    .setLevel(HttpLoggingInterceptor.Level.BODY);

    private static OkHttpClient.Builder httpClient =
            new OkHttpClient.Builder();

    public static <S> S createService(
            Class<S> serviceClass) {
        if (!httpClient.interceptors().contains(logging)) {
            httpClient.addInterceptor(logging);
            builder.client(httpClient.build());
            retrofit = builder.build();
        }

        return retrofit.create(serviceClass);
    }

}
